Thanks for grading my project.

The proj4.tar contains the folloeing files:
1. proj4_driver.cpp (same as the one from the provided code.)
2. bet.hpp
3. bet.h
4. analysis.txt
5. test.txt
6. proj4.x (made by th makefile, you can complie it by you own.)
7. readme.txt

For running the code, you can compile it by typing make.
Then it will have a file named proj4.x.

Run it alone, it will ask you to input the equation.
Or run it with the provided test file : proj4.x < test.txt.

Thank you very much.

Yuze
